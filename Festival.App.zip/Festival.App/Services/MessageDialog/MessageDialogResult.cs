﻿
namespace Festival.App.Services.MessageDialog
{
    public enum MessageDialogResult
    {
        Ok,
        Yes,
        No,
        Cancel
    }
}
