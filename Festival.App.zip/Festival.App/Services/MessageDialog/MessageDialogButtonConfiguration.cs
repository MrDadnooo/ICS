﻿
namespace Festival.App.Services.MessageDialog
{
    public enum MessageDialogButtonConfiguration
    {
        Ok,
        OkCancel,
        YesNoCancel,
        YesNo
    }
}
