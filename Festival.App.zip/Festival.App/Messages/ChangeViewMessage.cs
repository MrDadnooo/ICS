﻿
namespace Festival.App.Messages
{
    class ChangeViewMessage :IMessage
    {
        public object viewToChange { get; set; }
    }
}
