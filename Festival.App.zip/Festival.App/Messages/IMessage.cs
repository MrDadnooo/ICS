﻿
namespace Festival.App.Messages
{
    public interface IMessage
    {
    }
}
