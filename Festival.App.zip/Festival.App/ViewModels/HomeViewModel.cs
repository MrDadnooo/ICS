﻿
namespace Festival.App.ViewModels
{
    public class HomeViewModel : ViewModelBase
    {
       
    }
}
